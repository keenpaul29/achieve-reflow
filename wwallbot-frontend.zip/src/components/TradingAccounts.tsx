import { CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export function TradingAccounts() {
  const accounts = [
    {
      name: "Standard",
      price: "$100",
      description: "Ideal for new traders entering the forex market.",
      features: [
        "Access to 25+ currency pairs",
        "Leverage up to 1:500",
        "Spreads from 1.2 pips",
        "24/5 customer support",
        "Educational webinars"
      ],
      popular: false
    },
    {
      name: "Pro",
      price: "$1,000",
      description: "For experienced traders seeking advanced features.",
      features: [
        "Access to 50+ currency pairs",
        "Raw spreads from 0.0 pips",
        "Low commission structure",
        "Dedicated account manager",
        "Advanced trading tools"
      ],
      popular: true
    },
    {
      name: "VIP",
      price: "$10,000",
      description: "Exclusive benefits for high-volume traders.",
      features: [
        "All currency pairs & indices",
        "Customizable leverage",
        "Zero commission on trades",
        "Personalized strategies",
        "Exclusive event invitations"
      ],
      popular: false
    }
  ];

  return (
    <section className="py-24 bg-muted/20 relative">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(28,141,190,0.1),transparent_40%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_right,rgba(28,141,190,0.1),transparent_40%)]" />
      <div className="container mx-auto px-4 relative">
        <div className="text-center mb-16 animate-fade-up">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Find the <span className="text-gradient">Perfect Account</span> for You
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            We offer a range of account types to suit every trader, from novice to professional.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 items-stretch">
          {accounts.map((account, index) => (
            <Card
              key={account.name}
              className={`flex flex-col rounded-2xl bg-card/60 backdrop-blur-lg border animate-fade-up hover-lift relative overflow-hidden ${
                account.popular
                  ? "border-primary/50 glow-border"
                  : "border-border/30"
              }`}
              style={{ animationDelay: `${index * 150}ms` }}
            >
              {account.popular && (
                <Badge variant="default" className="absolute top-4 right-4 bg-gradient-accent text-primary-foreground">
                  Most Popular
                </Badge>
              )}
              <CardHeader className="text-center pt-8 pb-4">
                <CardTitle className="text-2xl font-bold mb-2">{account.name}</CardTitle>
                <CardDescription className="px-4">{account.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow p-6 flex flex-col">
                <div className="text-center my-4">
                  <span className="text-5xl font-bold text-primary">{account.price}</span>
                  <p className="text-sm text-muted-foreground mt-1">Minimum Deposit</p>
                </div>
                <ul className="space-y-3 text-sm flex-grow">
                  {account.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-3">
                      <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0" />
                      <span className="text-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  className="w-full mt-8 rounded-full font-semibold"
                  size="lg"
                  variant={account.popular ? "default" : "outline"}
                >
                  Open Account
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
