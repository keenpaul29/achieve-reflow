import { BarChart3, Lock, Smartphone, Headphones, Globe, Wallet, Zap } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export function Features() {
  const features = [
    {
      icon: BarChart3,
      title: "Advanced Charting",
      description: "Professional-grade charts with 100+ technical indicators and drawing tools."
    },
    {
      icon: Lock,
      title: "Bank-Level Security",
      description: "Multi-layer encryption and 2FA to keep your funds and data secure."
    },
    {
      icon: Smartphone,
      title: "Mobile Trading",
      description: "Trade on the go with our powerful mobile apps for iOS and Android."
    },
    {
      icon: Headphones,
      title: "24/7 Support",
      description: "Expert support team available around the clock to assist you."
    },
    {
      icon: Globe,
      title: "Global Markets",
      description: "Access to forex, stocks, commodities, and cryptocurrencies."
    },
    {
      icon: Wallet,
      title: "Fast Withdrawals",
      description: "Quick and easy withdrawals processed within 24 hours."
    },
    {
      icon: Zap,
      title: "Lightning Execution",
      description: "Experience ultra-low latency and rapid order execution."
    }
  ];

  return (
    <section className="py-24 bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(28,141,190,0.1),transparent_40%)]" />
      
      <div className="container mx-auto px-4 relative">
        <div className="text-center mb-16 animate-fade-up">
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-4 tracking-wide">
            CORE FEATURES
          </span>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Trade Smarter with <span className="text-gradient">Wwallbot</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Our platform is engineered for performance, reliability, and user experience, giving you the edge you need to navigate the markets.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card
              key={feature.title}
              className="group hover-lift border-transparent bg-card/50 backdrop-blur-sm animate-fade-up glow-border rounded-xl flex flex-col h-full overflow-hidden"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardHeader className="flex-shrink-0">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary/80 to-accent/60 flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:rotate-6">
                    <feature.icon className="h-6 w-6 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-lg font-bold transition-colors group-hover:text-primary">
                    {feature.title}
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <CardDescription className="text-base text-muted-foreground">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
