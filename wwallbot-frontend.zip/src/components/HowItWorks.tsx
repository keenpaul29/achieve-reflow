import { Briefcase, DollarSign, TrendingUp } from "lucide-react";

export function HowItWorks() {
  const steps = [
    {
      icon: <Briefcase className="w-10 h-10 text-primary" />,
      title: "Register & Verify",
      desc: "Complete our simple and secure registration process to create your trading account.",
    },
    {
      icon: <DollarSign className="w-10 h-10 text-primary" />,
      title: "Fund Your Account",
      desc: "Choose from a variety of convenient payment methods to deposit funds.",
    },
    {
      icon: <TrendingUp className="w-10 h-10 text-primary" />,
      title: "Start Trading",
      desc: "Access global markets and start trading with our advanced platforms and tools.",
    },
  ];

  return (
    <section className="py-24 bg-background relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background to-transparent" />
      <div className="container mx-auto px-4 relative">
        <div className="text-center mb-20 animate-fade-up">
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-4 tracking-wide">
            GET STARTED
          </span>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Begin Your Trading Journey in <span className="text-gradient">3 Easy Steps</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Our streamlined process ensures you can get your trading account up and running in minutes.
          </p>
        </div>
        
        <div className="relative">
          <div 
            className="hidden md:block absolute top-1/2 left-0 w-full h-1 bg-border/20"
            style={{ transform: 'translateY(-50%)' }}
          >
            <div className="h-1 bg-gradient-to-r from-primary/50 to-accent/50 w-full animate-glow" />
          </div>
          
          <div className="grid md:grid-cols-3 gap-12 relative">
            {steps.map((step, index) => (
              <div 
                key={step.title} 
                className="text-center animate-fade-up"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <div className="relative inline-block">
                  <div className="w-28 h-28 rounded-full bg-card border-2 border-primary/20 flex items-center justify-center mx-auto mb-6 shadow-lg transition-all duration-300 hover:shadow-primary/20 hover:border-primary/50">
                    {step.icon}
                  </div>
                  <div className="absolute -top-2 -right-2 w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-lg font-bold border-4 border-background">
                    {index + 1}
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2 text-foreground">{step.title}</h3>
                <p className="text-muted-foreground px-4">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
